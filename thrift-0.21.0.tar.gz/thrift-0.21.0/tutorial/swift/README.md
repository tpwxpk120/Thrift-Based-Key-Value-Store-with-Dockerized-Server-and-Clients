# Thrift Swift Tutorial
==================================================

## Run the tutorial code (client + server):
`make tutorial`

## Run the server only
`make tutorialserver`

## Run the client only
`make tutorialclient`
