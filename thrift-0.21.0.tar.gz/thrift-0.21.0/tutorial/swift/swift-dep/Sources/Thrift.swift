class Thrift {
	let version = "0.21.0"
}
